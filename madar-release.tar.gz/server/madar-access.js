import {n as account} from './_next/static/auth-service-Bi2xLom_.js';
const json=(body,status=200,headers={})=>Response.json(body,{status,headers:{'Cache-Control':'no-store',...headers}});
const schema=`CREATE TABLE IF NOT EXISTS initiative_feedback (respondent_id TEXT PRIMARY KEY, role TEXT NOT NULL, ratings TEXT NOT NULL, comment TEXT NOT NULL, updated_at TEXT NOT NULL)`;
export async function handleAccess(request,env){
 const url=new URL(request.url),path=url.pathname.replace(/\/+$/,'')||'/';
 const protectedPage=['/first','/second','/third','/progress'].includes(path);
 const feedback=path==='/api/feedback',report=path==='/api/teacher-feedback';
 if(!protectedPage&&!feedback&&!report)return null;
 const user=await account(request);
 if(protectedPage){if(user)return null;const dest=new URL('/',url.origin);dest.searchParams.set('returnTo',url.pathname+url.search);return new Response(null,{status:303,headers:{Location:dest.pathname+dest.search+'#grades','Cache-Control':'no-store'}});}
 if(report){if(!user)return json({error:'يلزم تسجيل الدخول.'},401);if(!user.teacher)return json({error:'هذه النتائج خاصة بإدارة مدار.'},403);if(request.method!=='GET')return json({error:'طريقة غير مسموحة.'},405);await env.DB.prepare(schema).run();const rows=(await env.DB.prepare('SELECT role,ratings,comment,updated_at FROM initiative_feedback ORDER BY updated_at DESC').all()).results.map(r=>({role:r.role,ratings:JSON.parse(r.ratings),comment:r.comment,updatedAt:r.updated_at}));return json({rows});}
 if(request.method!=='POST')return json({error:'طريقة غير مسموحة.'},405);
 if(request.headers.get('origin')!==url.origin||!request.headers.get('content-type')?.includes('application/json'))return json({error:'طلب غير مسموح.'},403);
 if(Number(request.headers.get('content-length')||0)>4096)return json({error:'الطلب طويل.'},400);
 let data;try{const text=await request.text();if(text.length>4096)return json({error:'الطلب طويل.'},400);data=JSON.parse(text);}catch{return json({error:'صيغة غير صالحة.'},400);}
 if(!['student','educator'].includes(data.role))return json({error:'اختاري نوع المستفيدة.'},400);
 if(data.role==='student'&&!user)return json({error:'سجلي الدخول لإرسال تقييم الطالبة.'},401);
 if(!Array.isArray(data.ratings)||data.ratings.length!==3||data.ratings.some(v=>!Number.isInteger(v)||v<1||v>5))return json({error:'أجيبي عن الأسئلة الثلاثة.'},400);
 const comment=String(data.comment||'').trim();if(comment.length>500)return json({error:'المقترح بحد أقصى 500 حرف.'},400);
 let guest=(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('__Host-madar_feedback='))?.split('=')[1];
 if(!/^[a-f0-9]{64}$/.test(guest||''))guest=Array.from(crypto.getRandomValues(new Uint8Array(32)),v=>v.toString(16).padStart(2,'0')).join('');
 const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(guest))),v=>v.toString(16).padStart(2,'0')).join('');
 const respondent=user?'account:'+user.id:'guest:'+digest;
 await env.DB.prepare(schema).run();
 await env.DB.prepare('INSERT INTO initiative_feedback (respondent_id,role,ratings,comment,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(respondent_id) DO UPDATE SET role=excluded.role,ratings=excluded.ratings,comment=excluded.comment,updated_at=excluded.updated_at').bind(respondent,data.role,JSON.stringify(data.ratings),comment,new Date().toISOString()).run();
 return json({ok:true},200,user?{}:{'Set-Cookie':`__Host-madar_feedback=${guest}; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=Lax`});
}

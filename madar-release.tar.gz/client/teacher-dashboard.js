(()=>{
 const $=id=>document.getElementById(id),names={first:'أول ثانوي',second:'ثاني ثانوي','third-term1':'ثالث · الفصل الأول','third-term2':'ثالث · الفصل الثاني'};
 let rows=[];
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const percent=x=>x==null?'—':x+'%';
 const date=s=>s?new Date(s).toLocaleString('ar-SA',{dateStyle:'short',timeStyle:'short'}):'—';
 const selected=()=>rows.filter(r=>(!$('track').value||r.track===$('track').value)&&(!$('classroom').value||r.classroom===$('classroom').value)&&r.name.includes($('search').value.trim()));
 const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length*10)/10:null;
 function measures(r){const p=r.progress;const done=p?.stations?.reduce((s,x)=>s+x.done,0)||0,total=p?.stations?.reduce((s,x)=>s+x.total,0)||0;return {pre:p?.pre?.percent??null,post:p?.post?.percent??null,gain:p?.pre&&p?.post?p.post.percent-p.pre.percent:null,done,total,mastery:total?Math.round(done/total*100):0};}
 function metric(title,value,note){return `<div class="metric"><span>${title}</span><b>${value}</b><small>${note}</small></div>`;}
 function render(){
  const list=selected(),users=new Set(list.map(r=>r.id)).size,measured=list.filter(r=>r.progress?.pre&&r.progress?.post),pre=list.filter(r=>r.progress?.pre).length,post=list.filter(r=>r.progress?.post).length;
  const gain=avg(measured.map(r=>measures(r).gain));const complete=list.filter(r=>{const m=measures(r);return m.total&&m.done===m.total;}).length;
  $('metrics').innerHTML=metric('الطالبات المسجلات',users,'عدد الطالبات الفريدات ضمن التصفية')+metric('إكمال القياس القبلي',pre,`من ${list.length} سجل طالبة / مسار`)+metric('إكمال القياس البعدي',post,`من ${list.length} سجل طالبة / مسار`)+metric('متوسط التغير',gain===null?'—':`${gain>0?'+':''}${gain}`,`نقطة مئوية · ${measured.length} زوج قبلي وبعدي`)+metric('إكمال جميع الجولات',complete,`من ${list.length} سجل طالبة / مسار`)+metric('متوسط إنجاز الجولات',list.length?percent(avg(list.map(r=>measures(r).mastery))):'—','متوسط نسبة الإنجاز لكل سجل في التصفية');
  $('rows').innerHTML=list.map(r=>{const m=measures(r);return `<tr><td>${esc(r.name)}</td><td>${esc(r.classroom)}</td><td>${esc(names[r.track]||'لم يبدأ مسارًا')}</td><td>${percent(m.pre)}</td><td>${percent(m.post)}</td><td>${m.gain===null?'—':(m.gain>0?'+':'')+m.gain}</td><td>${m.total?m.done+' / '+m.total+' · '+m.mastery+'%':'—'}</td><td>${details(r)}</td><td>${esc(date(r.updatedAt))}</td></tr>`;}).join('');$('empty').hidden=list.length!==0;
  const skills=new Map();
  for(const r of list){for(const [phase,assessment] of [['بعدي',r.progress?.post],['قبلي',r.progress?.post?null:r.progress?.pre]]){for(const [skill,v] of Object.entries(assessment?.skills||{})){const key=r.track+'|'+phase+'|'+skill;if(!skills.has(key))skills.set(key,{skill,track:r.track,phase,values:[]});skills.get(key).values.push(v.correct/v.total*100);}}}
  const entries=[...skills.values()].map(s=>({...s,score:avg(s.values)})).sort((a,b)=>a.score-b.score).slice(0,12);
  $('skills').innerHTML=entries.length?entries.map(s=>`<div class="skill"><div><b>${esc(s.skill)}</b><div class="muted">${esc(names[s.track])} · ${s.phase} · ${s.values.length} قياس</div><div class="bar"><i style="width:${s.score}%"></i></div></div><strong>${s.score}%</strong></div>`).join(''):'<p class="empty">تظهر المهارات بعد تسجيل القياسات.</p>';
  $('export').disabled=!list.length;
 }
 function details(r){if(!r.progress)return '—';const p=r.progress;
  const stations=(p.stations||[]).map(s=>`<li>${esc(s.name)}: ${s.done} / ${s.total} جولات</li>`).join('');
  const skillList=(a,label)=>a?`<b>${label}</b><ul>${Object.entries(a.skills||{}).map(([n,s])=>`<li>${esc(n)}: ${s.correct} / ${s.total} · ${Math.round(s.correct/s.total*100)}%</li>`).join('')}</ul>`:'';
  return `<details><summary>المحطات والمهارات</summary><ul>${stations}</ul>${skillList(p.pre,'المهارات القبلية')}${skillList(p.post,'المهارات البعدية')}</details>`;
 }
 async function load(){
  $('refresh').disabled=true;
  try{const response=await fetch('/api/teacher',{cache:'no-store',credentials:'same-origin'}),data=await response.json();if(!response.ok)throw new Error(data.error||'تعذر تحميل النتائج.');rows=data.rows;$('content').hidden=false;$('status').className='muted';$('status').textContent='آخر تحديث: '+date(data.asOf);
   const current=$('classroom').value;$('classroom').innerHTML='<option value="">جميع الشعب</option>'+[...new Set(rows.map(r=>r.classroom))].sort().map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');$('classroom').value=current;render();
  }catch(e){$('status').className='error';$('status').textContent=e.message;if(!document.getElementById('teacherLogin')){const a=document.createElement('a');a.id='teacherLogin';a.href='/?returnTo=/teacher';a.className='ghost';a.textContent='تسجيل الدخول بحساب المعلمة في مدار';$('status').append(document.createElement('br'),a);}if(!rows.length)$('content').hidden=true;}finally{$('refresh').disabled=false;}
 }
 function csvCell(value){let v=String(value??'');if(typeof value==='string'&&/^[=+\-@\t\r]/.test(v))v="'"+v;return '"'+v.replaceAll('"','""')+'"';}
 function exportReport(){
  const list=selected(),records=[['مدار — تقرير متابعة المبادرة التعليمية'],['المعلمة / سلوى الزهراني'],['الثانوية الحادية عشرة'],['تاريخ استخراج التقرير',new Date().toLocaleString('ar-SA')],['المسار',names[$('track').value]||'جميع المسارات'],['الشعبة',$('classroom').value||'جميع الشعب'],[],['الطالبة','الشعبة','المسار','القبلي %','البعدي %','التغير بالنقاط المئوية','الجولات المكتملة','إجمالي الجولات','إنجاز الجولات %','آخر تحديث']];
  for(const r of list){const m=measures(r);records.push([r.name,r.classroom,names[r.track]||'—',m.pre??'—',m.post??'—',m.gain??'—',m.done,m.total,m.mastery,date(r.updatedAt)]);}
  records.push([],['تفاصيل المهارات'],['الطالبة','الشعبة','المسار','نوع القياس','المهارة','الصحيح','عدد الأسئلة','النسبة %']);
  for(const r of list)for(const [phase,a] of [['قبلي',r.progress?.pre],['بعدي',r.progress?.post]])for(const [skill,v] of Object.entries(a?.skills||{}))records.push([r.name,r.classroom,names[r.track],phase,skill,v.correct,v.total,Math.round(v.correct/v.total*100)]);
  const blob=new Blob(['\uFEFF'+records.map(row=>row.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='madar-follow-up-'+new Date().toISOString().slice(0,10)+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 for(const id of ['track','classroom','search'])$(id).addEventListener(id==='search'?'input':'change',render);
 $('refresh').addEventListener('click',load);$('export').addEventListener('click',exportReport);load();setInterval(()=>{if(!document.hidden)load();},60000);
})();

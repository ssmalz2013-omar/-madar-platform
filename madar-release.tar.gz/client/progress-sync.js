(()=>{
 let me=null,ready=false,timer=null,running=false,again=false;
 const tracks=['first','second','third-term1','third-term2'];
 const el=document.createElement('section');el.className='madar-cloud-card';el.setAttribute('aria-label','حفظ التقدم');
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const api=async(path,data)=>{const r=await fetch('/api/'+path,{method:data?'POST':'GET',credentials:'same-origin',cache:'no-store',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined});const j=await r.json();if(!r.ok)throw new Error(j.error||'تعذر الاتصال.');return j;};
 const current=()=>{const g=localStorage.getItem('madar-grade')||'first';return g==='third'?'third-'+(localStorage.getItem('madar-third-active-term')||'term1'):g;};
 const defs=()=>({
  first:{prefix:'madar-first',bank:firstTrainingStationsData,get:firstStationStorage,pre:firstPretestQuestions,post:firstPosttestQuestions,station:'madar-first-station-'},
  second:{prefix:'madar-second',bank:secondTrainingStationsData,get:secondStationStorage,pre:secondPretestQuestions,post:secondPosttestQuestions,station:'madar-second-station-'},
  'third-term1':{prefix:'madar-third',bank:trainingStationsData,get:id=>stationStorage('term1',id),pre:thirdPretestQuestions,post:thirdPosttestQuestions,station:'madar-station-'},
  'third-term2':{prefix:'madar-third-term2',bank:trainingStationsData2,get:id=>stationStorage('term2',id),pre:thirdTerm2PretestQuestions,post:thirdTerm2PosttestQuestions,station:'madar-term2-station-'}
 });
 const progressKey=k=>/^(madar-(?:first|second|third(?:-term2)?)-(?:pretest|posttest)-(?:score|percent|skills|date)|madar-(?:first-|second-|term2-)?station-.+)$/.test(k);
 function snapshot(track){
  const d=defs()[track],storage={};
  const assessment=(type,questions)=>{
   const score=localStorage.getItem(d.prefix+'-'+type+'-score');if(score===null)return null;
   let skills={};try{skills=JSON.parse(localStorage.getItem(d.prefix+'-'+type+'-skills')||'{}')}catch{}
   return {score:Number(score),total:questions.length,skills,date:localStorage.getItem(d.prefix+'-'+type+'-date')};
  };
  for(const type of ['pretest','posttest'])for(const key of ['score','percent','skills','date']){const k=d.prefix+'-'+type+'-'+key,v=localStorage.getItem(k);if(v!==null)storage[k]=v;}
  const stations=d.bank.map(s=>{const total=s.rounds?s.rounds.length:Math.ceil(s.questions.length/6),st=d.get(s.id);const k=d.station+s.id,v=localStorage.getItem(k);if(v!==null)storage[k]=v;return {id:s.id,name:s.title,total,done:(st.rounds||[]).slice(0,total).filter(Boolean).length};});
  return {track,pre:assessment('pretest',d.pre),post:assessment('posttest',d.post),stations,storage};
 }
 function redraw(){
  for(const f of ['renderFirstStations','renderSecondStations','updateFirstProgressDashboard','updateSecondProgressDashboard','updateProgressDashboard','updateProgressDashboard2','updateJourneyLocks'])if(typeof window[f]==='function')window[f]();
  if(typeof renderStations==='function'){renderStations('term1');renderStations('term2');}
 }
 function status(text){const p=el.querySelector('[data-status]');if(p)p.textContent=text;}
 function show(){
  el.innerHTML=(me?.teacher?'<a class="btn" href="/teacher">لوحة متابعة المبادرة للمعلمة <svg class="ui-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="/icons/lucide.svg?v=26#arrow-up-right"></use></svg></a>':'')+(me?.profile?`<p>حفظ التقدم باسم <b>${escape(me.profile.name)}</b> · ${escape(me.profile.classroom)}</p><button type="button" class="ghost" data-edit>تعديل الاسم والفصل</button><button type="button" class="ghost" data-sync>إعادة المزامنة</button><button type="button" class="ghost" data-logout>تسجيل الخروج</button>`:'<p><b>احفظي رحلتك في مدار</b></p><p>أدخلي اسمك وفصلك لربط نتائجك بلوحة معلمتك واستعادتها عند تسجيل الدخول من جهاز آخر.</p>')+'<p data-status role="status" aria-live="polite"></p>';
  el.querySelector('[data-edit]')?.addEventListener('click',profileForm);el.querySelector('[data-sync]')?.addEventListener('click',()=>sync());
  el.querySelector('[data-logout]')?.addEventListener('click',logout);if(!me?.profile)profileForm();
 }
 function profileForm(){
  const old=el.querySelector('form');if(old)return;
  const f=document.createElement('form');f.innerHTML=`<label>الاسم<input name="name" required minlength="2" maxlength="100" autocomplete="name" value="${escape(me?.profile?.name||'')}"></label><label>الفصل / الشعبة<input name="classroom" required maxlength="60" placeholder="مثال: ثالث / ٣" value="${escape(me?.profile?.classroom||'')}"></label><button class="btn" type="submit">حفظ وربط النتائج</button><p>النتائج السابقة الموجودة على هذا الجهاز ستُربط بالاسم المدخل.</p>`;
  el.append(f);f.addEventListener('submit',async event=>{event.preventDefault();const button=f.querySelector('button');button.disabled=true;try{const data={name:f.elements.name.value.trim(),classroom:f.elements.classroom.value.trim()};await api('profile',data);me.profile=data;localStorage.setItem('madar-cloud-user',me.id);ready=true;show();await sync();}catch(e){status(e.message);button.disabled=false;}});
 }
 async function sync(){
  if(!ready||!me?.profile)return;
  if(running){again=true;return;}running=true;status('جارٍ حفظ التقدم…');
  try{for(const track of tracks){const p=snapshot(track);if(track===current()||p.pre||p.post||p.stations.some(s=>s.done))await api('progress',p);}status('تم حفظ التقدم في حسابك');}
  catch(e){status('نتائجك محفوظة على الجهاز؛ لم تكتمل المزامنة. '+e.message);}
  finally{running=false;if(again){again=false;queue();}}
 }
 function queue(){clearTimeout(timer);timer=setTimeout(sync,800);}
 window.madarSync=queue;
 function clearLocalAccount(){
  const keys=[];for(let i=0;i<localStorage.length;i++)keys.push(localStorage.key(i));keys.filter(progressKey).forEach(k=>localStorage.removeItem(k));localStorage.removeItem('madar-cloud-user');redraw();
 }
 async function logout(){
  ready=false;clearTimeout(timer);try{await api('auth/logout',{});clearLocalAccount();me=null;document.querySelectorAll('[data-teacher-link]').forEach(a=>a.hidden=true);authForm();}catch(e){status(e.message);}
 }
 function authForm(mode='login'){
  ready=false;const register=mode==='register';
  el.innerHTML=`<div class="account-heading"><h2>حسابك في مدار</h2><p>سجّلي الدخول لحفظ تقدمك ومتابعته من أي جهاز.</p></div><div class="account-tabs"><button type="button" class="ghost" data-mode="login" aria-pressed="${!register}">تسجيل الدخول</button><button type="button" class="ghost" data-mode="register" aria-pressed="${register}">إنشاء حساب</button></div><form class="account-form">${register?'<label>نوع الحساب<select name="kind"><option value="student">حساب المستخدم</option><option value="teacher">حساب إدارة مدار</option></select><small>حساب المستخدم متاح للطالبات والمعلمات دون رمز. حساب الإدارة خاص بالمعلمة سلوى الزهراني.</small></label><label>الاسم<input name="name" required minlength="2" maxlength="100" autocomplete="name"></label><label data-classroom>الفصل / الشعبة<input name="classroom" required maxlength="60" placeholder="مثال: أول / ١، أو تجربة للمعلمات"></label>':''}<label>اسم المستخدم<input name="username" required minlength="3" maxlength="40" autocomplete="username" autocapitalize="none" spellcheck="false" dir="auto" placeholder="مثال: سلوى01 أو salwa01"><small>حروف عربية أو إنجليزية وأرقام، دون مسافات.</small></label><label>كلمة المرور<input name="password" type="password" required minlength="10" maxlength="128" autocomplete="${register?'new-password':'current-password'}"><small>١٠ أحرف على الأقل.</small></label>${register?'<label>تأكيد كلمة المرور<input name="confirm" type="password" required minlength="10" maxlength="128" autocomplete="new-password"></label><label data-setup hidden>رمز تهيئة الإدارة<input name="setupCode" autocomplete="off" dir="ltr"><small>خاص بإدارة مدار ويُستخدم مرة واحدة.</small></label>':''}<button class="btn" type="submit">${register?'إنشاء الحساب وحفظ النتائج':'دخول إلى مدار'}</button></form><p data-status role="status" aria-live="polite"></p><p class="account-note">يمكنكِ متابعة التدريب دون تسجيل؛ يُحفظ تقدمك في حساب مدار بعد الدخول.</p>`;
  el.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>authForm(b.dataset.mode)));
  const form=el.querySelector('form');
  form.elements.kind?.addEventListener('change',()=>{const teacher=form.elements.kind.value==='teacher';el.querySelector('[data-setup]').hidden=!teacher;form.elements.setupCode.required=teacher;el.querySelector('[data-classroom]').hidden=teacher;form.elements.classroom.required=!teacher;});
  form.addEventListener('submit',async event=>{
   event.preventDefault();const button=form.querySelector('button[type="submit"]');
   if(register&&form.elements.password.value!==form.elements.confirm.value){status('كلمتا المرور غير متطابقتين.');return;}
   button.disabled=true;status('جارٍ '+(register?'إنشاء الحساب…':'تسجيل الدخول…'));
   try{const data={username:form.elements.username.value.trim(),password:form.elements.password.value};if(register)Object.assign(data,{name:form.elements.name.value.trim(),classroom:form.elements.classroom.value.trim(),kind:form.elements.kind.value,setupCode:form.elements.setupCode.value.trim()});await api('auth/'+mode,data);await init();if(me?.teacher&&new URLSearchParams(location.search).get('returnTo')==='/teacher')location.assign('/teacher');}
   catch(e){status(e.message);button.disabled=false;}
  });
 }
 async function init(){
  ((window.madarPage!=='home'&&document.getElementById('accountPanel'))||document.getElementById('grades')||document.querySelector('main')||document.body).prepend(el);
  try{
   me=await api('me');
   document.querySelectorAll('[data-teacher-link]').forEach(a=>a.hidden=!me.teacher);
   const old=localStorage.getItem('madar-cloud-user');
   if(old&&old!==me.id)clearLocalAccount();
   if(me.profile){
    for(const saved of me.progress){const local=snapshot(saved.track);const localDates=[local.pre?.date,local.post?.date].filter(Boolean).sort();const newer=localDates.at(-1)>saved.updatedAt;
     for(const [k,v] of Object.entries(saved.storage||{}))if(progressKey(k)){
      if(k.includes('-station-')||k.startsWith('madar-station-')){
       let a={},b={};try{a=JSON.parse(localStorage.getItem(k)||'{}');b=JSON.parse(v);}catch{}
       const n=Math.max((a.rounds||[]).length,(b.rounds||[]).length);
       localStorage.setItem(k,JSON.stringify({...b,...a,rounds:Array.from({length:n},(_,i)=>!!a.rounds?.[i]||!!b.rounds?.[i])}));
      }else if(!newer||localStorage.getItem(k)===null)localStorage.setItem(k,v);
     }
    }
    localStorage.setItem('madar-cloud-user',me.id);ready=true;redraw();
   }
   show();if(ready)queue();
  }catch(e){me=null;authForm();if(!e.message.includes('تسجيل الدخول'))status('تعذر الاتصال بالحساب. يمكنك متابعة التدريب ثم المحاولة مجددًا.');}
 }
 window.addEventListener('online',queue);
 window.addEventListener('storage',queue);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)queue();});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

(()=>{
 const page=document.body.dataset.page||'home',validGrades=['first','second','third'];
 const saved=localStorage.getItem('madar-grade'),grade=validGrades.includes(saved)?saved:'first';
 const term=localStorage.getItem('madar-third-active-term')==='term2'?'term2':'term1';
 const gradeUrl='/'+grade+(grade==='third'?'?term='+term:'');
 const progressUrl='/progress?grade='+grade+(grade==='third'?'&term='+term:'');
 document.body.dataset.grade=grade;
 const navbar=document.querySelector('.page-navbar'),toggle=navbar?.querySelector('.navbar-toggle');
 toggle?.addEventListener('click',()=>{const open=navbar.classList.toggle('nav-open');toggle.setAttribute('aria-expanded',String(open));});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&navbar?.classList.contains('nav-open')){navbar.classList.remove('nav-open');toggle.setAttribute('aria-expanded','false');toggle.focus();}});
 if(page==='teacher')return;
 const trainingLinks={'#firstTraining':'/first#firstTraining','#secondTraining':'/second#secondTraining','#thirdTraining':'/third?term=term1#thirdTraining','#thirdTraining2':'/third?term=term2#thirdTraining2'};
 const map={'#home':'/','#grades':'/#grades','#journey':gradeUrl,'#stations':'/learning','#achievements':progressUrl+'#achievements','#progress':progressUrl,'#progress2':'/progress?grade=third&term=term2','#firstProgress':'/progress?grade=first','#secondProgress':'/progress?grade=second'};
 document.querySelectorAll('a[href^="#"]').forEach(a=>{const href=a.getAttribute('href');if(map[href])a.href=map[href];else if(trainingLinks[href]&&!((page==='first'&&href==='#firstTraining')||(page==='second'&&href==='#secondTraining')||(page==='third'&&href.startsWith('#thirdTraining'))))a.href=trainingLinks[href];});
 document.querySelectorAll('.grade-card').forEach(card=>{const url='/'+card.dataset.grade;const a=card.querySelector('a');if(a)a.href=url;card.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();location.assign(url);},true);card.setAttribute('tabindex','0');card.setAttribute('role','link');card.addEventListener('keydown',e=>{if(e.key==='Enter')location.assign(url);});});
 const report=document.getElementById('homeReportLink');if(report)report.href=progressUrl;
 if(page==='progress'){
  const gs=document.getElementById('resultGrade'),ts=document.getElementById('resultTerm');gs.value=grade;ts.value=term;document.getElementById('resultTermLabel').hidden=grade!=='third';document.getElementById('returnToTraining').href=gradeUrl;
  const go=()=>location.assign('/progress?grade='+gs.value+(gs.value==='third'?'&term='+ts.value:''));gs.addEventListener('change',go);ts.addEventListener('change',go);
  const badges=document.getElementById('achievements');if(badges)document.querySelector('main').append(badges);
 }
 const openLinkedStation=()=>{
  const id=new URL(location.href).searchParams.get('station');if(!id||!window.madarAccountReady)return;
  if(page==='first')openFirstStation(id);
  else if(page==='second')openSecondStation(id);
  else if(page==='third')openStation(id,term);
 };
 window.addEventListener('madar-auth-ready',openLinkedStation);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',openLinkedStation);else openLinkedStation();
 if(page==='home'){
  const hash=location.hash;const legacy={'#firstTraining':'/first#firstTraining','#secondTraining':'/second#secondTraining','#thirdTraining':'/third?term=term1#thirdTraining','#thirdTraining2':'/third?term=term2#thirdTraining2',...map};
  if(hash&&hash!=='#home'&&hash!=='#grades'&&legacy[hash])location.replace(legacy[hash]);
 }
})();

(()=>{
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function context(){
  const grade=localStorage.getItem('madar-grade')||'first',term=localStorage.getItem('madar-third-active-term')||'term1';
  if(grade==='first')return {prefix:'madar-first',bank:firstTrainingStationsData,open:openFirstStation,quiz:()=>openFirstQuiz('post')};
  if(grade==='second')return {prefix:'madar-second',bank:secondTrainingStationsData,open:openSecondStation,quiz:()=>openSecondQuiz('post')};
  return {prefix:term==='term2'?'madar-third-term2':'madar-third',bank:term==='term2'?trainingStationsData2:trainingStationsData,open:id=>openStation(id,term),quiz:()=>openQuiz('post',term)};
 }
 function build(host,c,skills,phase){
  host.replaceChildren();
  const entries=Object.entries(skills).filter(([,s])=>s&&Number.isFinite(s.correct)&&s.total>0).map(([name,s])=>({name,score:Math.round(s.correct/s.total*100),station:c.bank.find(x=>x.title===name)})).sort((a,b)=>a.score-b.score);
  if(!entries.length)return;
  const weak=entries.filter(x=>x.score<70);
  host.innerHTML='<h3>تدريب موجّه حسب نتائجك</h3><p>النتائج حسب موضوعات القياس '+esc(phase)+'. تُقترح مراجعة الموضوعات الأقل من 70%؛ وهذه عتبة للدعم وليست حكمًا على الإتقان.</p>'+(weak.length?weak.map((x,i)=>'<div style="margin:12px 0"><b>'+esc(x.name)+' — '+x.score+'%</b> '+(x.station?'<button type="button" class="ghost" data-practice="'+i+'">راجعي وتدرّبي</button>':'<span>راجعي هذا الموضوع مع معلمتك.</span>')+'</div>').join(''):'<p>لا توجد موضوعات أقل من عتبة الدعم في هذا القياس.</p>')+'<p>بعد التدريب يمكنك إعادة القياس البعدي. تُحدّث الإعادة النتيجة البعدية السابقة في حسابك.</p>';
  host.querySelectorAll('[data-practice]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('closeResult')?.click();c.open(weak[Number(b.dataset.practice)].station.id);}));
 }
 function refresh(){
  let c;try{c=context();}catch{return;}
  let skills={},phase='القبلي';try{const post=localStorage.getItem(c.prefix+'-posttest-skills');skills=JSON.parse(post||localStorage.getItem(c.prefix+'-pretest-skills')||'{}');if(post)phase='البعدي';}catch{return;}
  for(const target of [document.getElementById('skillBreakdown'),window.madarPage==='progress'?document.getElementById('accountPanel'):null]){
   if(!target)continue;
   let host=target.querySelector('[data-targeted-practice]');if(!host){host=document.createElement('section');host.dataset.targetedPractice='';host.style.cssText='padding:16px;margin:16px 0;border:1px solid #dce3f0;border-radius:16px;background:#fff';target.append(host);}
   const signature=JSON.stringify([c.prefix,phase,skills]);if(host.dataset.signature!==signature){build(host,c,skills,phase);host.dataset.signature=signature;}
  }
 }
 document.addEventListener('change',()=>setTimeout(refresh,0));
 document.addEventListener('click',()=>setTimeout(refresh,0));
 window.addEventListener('storage',refresh);setInterval(refresh,2000);refresh();
})();

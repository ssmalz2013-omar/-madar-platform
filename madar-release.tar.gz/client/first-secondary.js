const firstStationContainer=document.getElementById("firstTrainingStations");
function openFirstQuiz(mode='pre'){
  quizGrade='first'; quizMode=mode; quizTerm='first';
  activeQuestions=mode==='post'?firstPosttestQuestions:firstPretestQuestions;
  currentQuestion=0;form.reset();form.hidden=false;resultBox.hidden=true;answerReview.innerHTML='';document.querySelector('.quiz-head').hidden=false;
  document.getElementById('quizKicker').textContent=`${mode==='post'?'القياس البعدي':'القياس القبلي'} • مدار أول ثانوي`;
  document.getElementById('quizTitle').textContent=mode==='post'?`${activeQuestions.length} سؤالًا لقياس أثر التعلم`:`${activeQuestions.length} سؤالًا لتحديد نقطة الانطلاق`;
  document.getElementById('quizIntro').textContent=mode==='post'?'أجيبي بعد إكمال المحطات ثم قارني نتيجتك بقياسك القبلي.':'اختاري الإجابة الأقرب لما تعرفينه الآن.';
  modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';renderQuiz();
}

function firstStationStorage(id){try{return JSON.parse(localStorage.getItem(`madar-first-station-${id}`)||'{}')}catch(e){return {}}}
function setFirstStationStorage(id,obj){localStorage.setItem(`madar-first-station-${id}`,JSON.stringify(obj));window.madarSync?.()}
function firstStationPct(s){const st=firstStationStorage(s.id),total=s.rounds.length,done=(st.rounds||[]).slice(0,total).filter(Boolean).length;return total?Math.round(done/total*100):0}
function hasFirstPretest(){return localStorage.getItem('madar-first-pretest-percent')!==null}
function allFirstStationsComplete(){return firstTrainingStationsData.every(s=>firstStationPct(s)===100)}
function renderFirstStations(){if(!firstStationContainer)return;const unlocked=true;firstStationContainer.innerHTML=stationLinksList(firstTrainingStationsData,'first');const launch=document.getElementById('firstTrainingLaunch');if(launch){launch.classList.toggle('locked',!unlocked);launch.setAttribute('aria-disabled',String(!unlocked));}document.querySelectorAll('.posttest-btn[data-grade-name="أول ثانوي"]').forEach(btn=>{btn.disabled=!allFirstStationsComplete();btn.classList.toggle('locked',!allFirstStationsComplete());});}
function openFirstStation(id){activeTrainingTerm='first';activeStation=firstTrainingStationsData.find(s=>s.id===id);if(!activeStation)return;document.getElementById('trainingKicker').textContent=`المحطة ${activeStation.num} • أول ثانوي`;document.getElementById('trainingTitle').textContent=activeStation.title;document.getElementById('trainingIntro').textContent=activeStation.desc+' اقرئي البطاقات ثم اختاري جولة.';document.getElementById('conceptCards').innerHTML=activeStation.concepts.map(c=>`<div class="concept-card"><b>${c[0]}</b><span>${scienceText(c[1])}</span></div>`).join('');const st=firstStationStorage(id),done=st.rounds||[];document.getElementById('roundButtons').innerHTML=activeStation.rounds.map((r,i)=>({r,i,visual:r.questions.some(q=>q[4]?.image)})).sort((a,b)=>Number(b.visual)-Number(a.visual)).map(({r,i,visual})=>`<button class="round-btn ${done[i]?'done':''} ${visual?'visual-round':''}" data-round="${i}"><span>${visual?'جديد • تدريب بالرسوم':'الجولة '+(i+1)} | ${r.title}</span><small>${done[i]?'مكتملة <svg class="ui-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="/icons/lucide.svg?v=26#check"></use></svg>':r.questions.length+' أسئلة'}</small></button>`).join('');document.querySelectorAll('.round-btn').forEach(b=>b.addEventListener('click',()=>startRound(Number(b.dataset.round))));document.getElementById('trainingHome').hidden=false;document.getElementById('trainingQuiz').hidden=true;trainingModal.classList.add('open');trainingModal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}


function updateFirstProgressDashboard(){
 for(const [type,id] of [['pretest','firstPreMetric'],['posttest','firstPostMetric']]){const v=localStorage.getItem('madar-first-'+type+'-percent');document.getElementById(id).textContent=v===null?'—':v+'%';}
 const pre=localStorage.getItem('madar-first-pretest-percent'),post=localStorage.getItem('madar-first-posttest-percent');
 document.getElementById('firstGainMetric').textContent=pre===null||post===null?'—':(Number(post)-Number(pre))+' نقطة مئوية';
 document.getElementById('firstMasteryMetric').textContent=Math.round(firstTrainingStationsData.reduce((n,s)=>n+firstStationPct(s),0)/firstTrainingStationsData.length)+'%';
 document.getElementById('firstProgressNote').textContent='النتائج محفوظة على هذا الجهاز. 0% نتيجة مقاسة، والشرطة تعني عدم وجود قياس.';
 labelAssessmentBars();updateHomeSummary();
}
document.addEventListener('DOMContentLoaded',()=>{renderFirstStations();updateFirstProgressDashboard();
window.addEventListener('hashchange',()=>{if(location.hash==='#firstTraining'||location.hash==='#firstProgress')chooseGrade('first');});
if(location.hash==='#firstTraining'||location.hash==='#firstProgress')chooseGrade('first');

});
